package com.example.user.uproad_main;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import java.util.ArrayList;

/**
 * Created by user on 2016-03-26.
 */
public class grid_main_customAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Integer> grid_mainList;

    public grid_main_customAdapter(Context context, ArrayList<Integer> grid_mainList) {
        this.context = context;
        this.grid_mainList = grid_mainList;
    }



    @Override
    public int getCount() {
        return grid_mainList.size();
    }

    @Override
    public Object getItem(int position) {
        return grid_mainList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View  mainImage = convertView;
        if(mainImage == null){
            LayoutInflater mainInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            mainImage =  mainInflater.inflate(R.layout.mainview_image,parent,false);
        }


        ImageView image1 =(ImageView)mainImage.findViewById(R.id.image1);
        ImageView image2 =(ImageView)mainImage.findViewById(R.id.image2);
        ImageView image3 =(ImageView)mainImage.findViewById(R.id.image3);
        ImageView image4 =(ImageView)mainImage.findViewById(R.id.image4);
        ImageView image5 =(ImageView)mainImage.findViewById(R.id.image5);
        ImageView image6 =(ImageView)mainImage.findViewById(R.id.image6);
        ImageView image7 =(ImageView)mainImage.findViewById(R.id.image7);
        ImageView image8 =(ImageView)mainImage.findViewById(R.id.image8);
        ImageView image9 =(ImageView)mainImage.findViewById(R.id.image9);
        ImageView image10 =(ImageView)mainImage.findViewById(R.id.image10);
        ImageView image11 =(ImageView)mainImage.findViewById(R.id.image11);
        ImageView image12 =(ImageView)mainImage.findViewById(R.id.image12);



        image1.setImageResource(grid_mainList.get(position));
        image2.setImageResource(grid_mainList.get(position));
        image3.setImageResource(grid_mainList.get(position));
        image4.setImageResource(grid_mainList.get(position));
        image5.setImageResource(grid_mainList.get(position));
        image6.setImageResource(grid_mainList.get(position));
        image7.setImageResource(grid_mainList.get(position));
        image8.setImageResource(grid_mainList.get(position));
        image9.setImageResource(grid_mainList.get(position));
        image10.setImageResource(grid_mainList.get(position));
        image11.setImageResource(grid_mainList.get(position));
        image12.setImageResource(grid_mainList.get(position));


        return mainImage;
    }
}