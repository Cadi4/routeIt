package com.example.user.uproad_main;

/**
 * Created by user on 2016-03-24.
 */
public class main_info {
    String name;

    public main_info(String name) {
        this.name = name;
    }
    public String getName(){
        return name;
    }
}
