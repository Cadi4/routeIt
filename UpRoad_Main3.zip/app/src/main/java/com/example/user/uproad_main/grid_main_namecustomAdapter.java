package com.example.user.uproad_main;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by user on 2016-03-26.
 */
public class grid_main_namecustomAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<main_info> nameList;

    public grid_main_namecustomAdapter(Context context, ArrayList<main_info> nameList) {
        this.context = context;
        this.nameList = nameList;
    }

    @Override
    public int getCount() {
        return nameList.size();
    }

    @Override
    public Object getItem(int position) {
        return nameList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View name = convertView;
        if (name == null) {
            LayoutInflater nameInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            name = nameInflater.inflate(R.layout.mainview_image, parent, false);

        }
        main_info maininfo = nameList.get(position);
        String mainName = maininfo.getName();

        TextView text1 = (TextView) name.findViewById(R.id.text1);
        TextView text2 = (TextView) name.findViewById(R.id.text2);
        TextView text3 = (TextView) name.findViewById(R.id.text3);
        TextView text4 = (TextView) name.findViewById(R.id.text4);
        TextView text5 = (TextView) name.findViewById(R.id.text5);
        TextView text6 = (TextView) name.findViewById(R.id.text6);
        TextView text7 = (TextView) name.findViewById(R.id.text7);
        TextView text8 = (TextView) name.findViewById(R.id.text8);
        TextView text9 = (TextView) name.findViewById(R.id.text9);
        TextView text10 = (TextView) name.findViewById(R.id.text10);
        TextView text11 = (TextView) name.findViewById(R.id.text11);
        TextView text12 = (TextView) name.findViewById(R.id.text12);

        text1.setText(mainName);
        text2.setText(mainName);
        text3.setText(mainName);
        text4.setText(mainName);
        text5.setText(mainName);
        text6.setText(mainName);
        text7.setText(mainName);
        text8.setText(mainName);
        text9.setText(mainName);
        text10.setText(mainName);
        text11.setText(mainName);
        text12.setText(mainName);

        return name;
    }
}