package com.example.user.uproad_main;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView home,search,game,mypage,logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final FragmentManager fragmentManager = getSupportFragmentManager();
        final android.support.v4.app.Fragment fragment = new Main_Fragment();
        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        home = (ImageView)findViewById(R.id.home);
        search = (ImageView)findViewById(R.id.search);
        game = (ImageView)findViewById(R.id.game);
        mypage = (ImageView)findViewById(R.id.mypage);
        logout = (ImageView)findViewById(R.id.logout);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.i(getClass().getSimpleName(),"home");
                startActivityFromFragment(,Main_Fragment.class);
                fragmentTransaction.replace(R.id.mainFrame,fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                fragmentTransaction.replace(R.id.searchFrame,fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
    }

}
