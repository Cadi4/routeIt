package com.example.user.uproad_main;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;

import java.util.ArrayList;

public class Search_Fragment extends Fragment {
    private OnFragmentInteractionListener mListener;

    public Search_Fragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        GridView grid_search;
        ArrayList<Integer> grid_mainList;
        ArrayList<main_info> place_name_List;
        View view = inflater.inflate(R.layout.fragment_search_,container,false);
        grid_mainList = new ArrayList<>();
        place_name_List = new ArrayList<>();


        grid_mainList.add(R .drawable.a1);
        grid_mainList.add(R.drawable.a2);
        grid_mainList.add(R.drawable.a3);
        grid_mainList.add(R.drawable.a4);
        grid_mainList.add(R.drawable.a5);
        grid_mainList.add(R.drawable.a6);
        grid_mainList.add(R.drawable.a7);
        grid_mainList.add(R.drawable.a8);
        grid_mainList.add(R.drawable.a9);

        grid_search = (GridView) view.findViewById(R.id.grid_search);
        grid_main_customAdapter main_customAdapter = new grid_main_customAdapter(getActivity().getApplicationContext(), grid_mainList);
        grid_main_namecustomAdapter namecustomAdapter = new grid_main_namecustomAdapter(getActivity().getApplicationContext(), place_name_List);
        place_name_List.add(new main_info("서울"));
        place_name_List.add(new main_info("인천"));
        place_name_List.add(new main_info("경기"));
        place_name_List.add(new main_info("대구"));
        place_name_List.add(new main_info("대전"));
        place_name_List.add(new main_info("광주"));
        place_name_List.add(new main_info("부산"));
        place_name_List.add(new main_info("울산"));
        place_name_List.add(new main_info("충청도"));

        grid_search.setAdapter(main_customAdapter);
        grid_search.setAdapter(namecustomAdapter);


        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
